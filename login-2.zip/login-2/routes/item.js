const itemRoutes = require('express').Router()
const ItemController = require('../controllers/ItemController')
itemRoutes.get('/', ItemController.getAllItems)
itemRoutes.post('/', ItemController.create)
itemRoutes.put('/:id', ItemController.update)
itemRoutes.delete('/:id', ItemController.delete)
itemRoutes.get('/account/:id', ItemController.getItemById)
module.exports = itemRoutes