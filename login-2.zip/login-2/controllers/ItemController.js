const  { Item } = require('../models')
class ItemController{
    static async getAllItems(req, res){

            
        }

    static create(req,res){

    }
    static update(req, res){

    }
    static delete(req,res){

    }
    static getItemById(req, res){
        
    }

}
module.exports = ItemController