const  { users } = require('../models')
const bcrypt = require('bcrypt')
class UserController {
    static async getAllUsers(req, res){
        try{
            let Users = await users.findAll()

            res.status(200).json(Users)

        }catch (err){
            res.status(500).json(err)
        }
            
        }

    static async register(req,res){
        try{
            const {username,email,password,role} = req.body
             const hashPwd = bcrypt.hashSync(String(password), 5)
             let result = await users.create({
                  username,email,password:hashPwd,role
              })
           
             res.status(201).json(result)

        } catch (err) {
            res.status(500).json(err)
        }
    }
    static async update(req, res){
        try {
            const id = +req.params.id
            const {username,email,password,role} = req.body;
            let result = await users.update({
                username,email,password,role
            }, {
                where: {id}
            })
            res.status(201).json(result)

        }catch (err) {
            res.status(500).json(err)
        }

    }
    static async login(req,res){
        try{
            const {email, password} = req.body
            let emailFound = await users.findOne({
                where:{
                    email
                }
            })
            if(emailFound){
                res.status(200).json(emailFound)
                
            }else{
                res.status(404).json({
                    message: 'User Not Found!'
                })
            }

           
        }catch (err){
            res.status(500).json(err)
        }
    }
    static async delete(req,res){
        try{
            const id = req.params.id
            let result = await users.destroy({
                where: {id}
            })
            result === 1 ?
            res.status(200).json({
                message : `User id ${id} deleted successfully!`
            }):
            res.status(404).json({
                message : `User id ${id} not deleted successfully`
            })

        }catch (err){
            res.status(500).json(err)
        }

    }
    static async getUserById(req, res){
        try{
            const id = +req.params.id
            let result = await users.findByPk(id)
            res.status(200).json(result)
        }catch (err){
            res.status(500).json(err)
        }
    }

}
module.exports = UserController